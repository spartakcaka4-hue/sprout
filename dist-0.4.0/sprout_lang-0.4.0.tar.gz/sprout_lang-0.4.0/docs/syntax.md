# Sprout v0.4 Syntax

Sprout programs are plain text files with the `.spr` extension.

Run one with:

```text
sprout path/to/program.spr
```

From a source checkout, `python sprout.py path/to/program.spr` is still
supported.

## Values

Sprout has Number, Text, Boolean, List, and `nothing`.

```text
score = 10
name = "Joel"
done = true
foods = ["pizza", "apple"]
missing = nothing
```

Numbers use Python-style floating-point behavior. That means this is expected:

```text
print(0.1 + 0.2)
```

Output:

```text
0.30000000000000004
```

Whole-number results print without `.0`, so `5.0` prints as `5`.

Text uses double quotes only. Supported escapes are `\"`, `\\`, `\n`, and
`\t`.

## Variables

Use `=` to assign and `==` to compare.

```text
score = 10
print(score == 10)
```

Names start with a letter or `_`, then may contain letters, digits, or `_`.
Keywords and built-in function names (`print`, `length`) cannot be reused as
variable, loop, parameter, or function names.

## Printing

Use commas to print several values with spaces between them:

```text
score = 10
print("Score:", score)
```

Output:

```text
Score: 10
```

Sprout does not combine Text and Numbers with `+`.

## Conditions

Conditions must be Boolean. Sprout has no truthiness.

```text
score = 10

if score >= 10:
    print("You win")
else if score >= 5:
    print("Close")
else:
    print("Try again")
```

Write explicit comparisons, such as `if score != 0:`.

Use `exists` to check whether a value is not `nothing`:

```text
winner = nothing

if winner exists:
    print("Winner:", winner)
else:
    print("No winner yet")
```

Output:

```text
No winner yet
```

`exists` means the same thing as `!= nothing`. It still evaluates the name on
the left normally, so a misspelled or undefined variable is still an error.

## Indentation

Blocks start with `:` and the body is indented exactly 4 spaces.

```text
if true:
    print("four spaces")
```

Tabs are always rejected in indentation. Empty blocks are not supported.

## Loops

Repeat a block a fixed number of times:

```text
repeat 3:
    print("Hello")
```

Use `as` to get a zero-based counter:

```text
repeat 3 as i:
    print("Lap", i)
```

Output:

```text
Lap 0
Lap 1
Lap 2
```

The counter is an ordinary variable assignment on each iteration. If the loop
runs zero times, the counter is not assigned.

Loop over list items:

```text
foods = ["pizza", "apple"]

for food in foods:
    print(food)
```

An empty list does not assign the loop variable unless it already had a value.

## Lists

Lists use square brackets and zero-based indexes.

```text
foods = ["pizza", "apple", "bread"]
print(foods[0])
print(length(foods))
```

Output:

```text
pizza
3
```

Indexes must be non-negative whole Numbers. Negative indexes and list item
assignment are not supported yet.

Lists compare structurally with `==` and `!=`:

```text
print([1, [2, 3]] == [1, [2, 3]])
```

Output:

```text
true
```

Ordering lists with `<`, `>`, `<=`, or `>=` is an error.

## Functions

Define functions with `func`.

```text
func add(a, b):
    return a + b

print(add(2, 3))
```

Output:

```text
5
```

Functions must be defined before they are called. There is no hoisting.
Functions can read globals, but assignments inside a function create or update
locals only.

A bare `return`, or reaching the end without `return`, gives `nothing`.
Functions are not ordinary values: call them by name instead of storing,
printing, returning, or putting them in lists.

## Tick Controls

Sprout includes a tick-control system. A tick is one complete simulation step.
In v0.4, ticks run live agent `every tick:` behavior first, then increment
`tick.number` after the complete step finishes.

Run one manual tick:

```text
tick.next()
print(tick.number)
```

Output:

```text
1
```

Run several manual ticks:

```text
tick.next(5)
print(tick.number)
```

Output:

```text
5
```

Start automatic ticking:

```text
tick.start(30)
```

The rate is ticks per second and must be greater than 0. Automatic ticking
continues until paused, stopped, or a breakpoint triggers.

Pause and resume:

```text
tick.start(30)
tick.pause
tick.resume
tick.stop
```

`tick.pause` lets the current tick finish, then pauses. `tick.resume` continues
using the previous automatic tick rate. Resuming without a paused automatic
session is a runtime error.

Stop automatic ticking:

```text
tick.stop
```

`tick.stop` lets the current tick finish, then ends the automatic session and
forgets the previous rate.

Breakpoints:

```text
tick.break at 10
tick.break when tick.number >= 20
```

`tick.break at N` pauses automatic ticking after tick `N` completes.
`tick.break when condition` checks a Boolean condition after each automatic
tick. Breakpoints do not stop manual `tick.next(...)` calls.

## Agent Declarations

Agent declarations define reusable agent types. In v0.4, those types can be
spawned as live instances, and an optional `every tick:` block runs while each
instance is active.

Use built-in presets to add common fields:

```text
agent Blob uses:
    position.basic
    movement.ground
    biology.energy

    hunger = 5
    vision = 10
```

Built-in preset fields and custom fields coexist. Duplicate field names are a
runtime error:

```text
agent Blob uses:
    biology.energy

    energy = 5
```

Only one preset from each category may be selected:

```text
agent Blob uses:
    position.basic
    position.cell
```

This is a runtime error because both presets are from `position`.

You can declare custom-only agents without `uses`:

```text
agent Note:
    label = "seed"
```

### Agent Presets

Position presets:

```text
position.none          # no fields
position.basic         # x, y
position.cell          # row, column
position.continuous    # x, y
```

Movement presets:

```text
movement.none          # no fields; active movement false
movement.directional   # speed, direction
movement.velocity      # velocity_x, velocity_y
movement.grid          # grid_x, grid_y
movement.ground        # speed, direction
movement.water         # speed, direction
movement.air           # speed, direction, altitude
movement.amphibious    # speed, direction
movement.aerial_ground # speed, direction, altitude
movement.passive       # direction; active movement false
```

Biology presets:

```text
biology.none           # no fields
biology.energy         # energy, alive
biology.health         # health, max_health, alive
biology.lifecycle      # age, lifespan, alive
```

The newer movement presets also store allowed environment metadata. They do not
perform movement calculations.

Preset fields have spawn defaults, copied independently into each live
instance:

| Preset | Defaults |
|---|---|
| `position.basic` | `x = 0`, `y = 0` |
| `position.cell` | `row = 0`, `column = 0` |
| `position.continuous` | `x = 0`, `y = 0` |
| `movement.directional`, `movement.ground`, `movement.water`, `movement.amphibious` | `speed = 1`, `direction = 0` |
| `movement.velocity` | `velocity_x = 0`, `velocity_y = 0` |
| `movement.grid` | `grid_x = 0`, `grid_y = 0` |
| `movement.air`, `movement.aerial_ground` | `speed = 1`, `direction = 0`, `altitude = 0` |
| `movement.passive` | `direction = 0` |
| `biology.energy` | `energy = 100`, `alive = true` |
| `biology.health` | `health = 100`, `max_health = 100`, `alive = true` |
| `biology.lifecycle` | `age = 0`, `lifespan = 100`, `alive = true` |

## Environments And Placement

Environment declarations define named environment types:

```text
environment Land:
    type = ground

environment Lake:
    type = water

environment Sky:
    type = air
```

Supported environment types are:

```text
ground
water
air
```

Place an agent type in an environment:

```text
agent Blob uses:
    position.continuous
    movement.ground

environment Land:
    type = ground

place Blob in Land
```

`place` validates that the agent exists, the environment exists, and the
agent's movement preset allows the environment type. It stores placement
metadata only; it does not create live agent instances.

Invalid placement example:

```text
agent Blob uses:
    position.continuous
    movement.ground

environment Sky:
    type = air

place Blob in Sky
```

This raises a runtime error because `movement.ground` cannot be placed in an
air environment.

`movement.passive` may be placed in any supported environment, but active
movement remains false. `movement.none` may also be placed in supported
environments as stationary metadata, with active movement false.

## Worlds

World declarations define bounded 2D runtime spaces with one default
environment. They do not render anything or generate terrain yet.

Continuous world:

```text
environment Land:
    type = ground

world Meadow:
    size = 100, 80
    space = continuous
    environment = Land
```

Grid world:

```text
environment Ground:
    type = ground

world Board:
    size = 20, 20
    space = grid
    environment = Ground
```

World declarations are top-level only. Each world block must contain exactly
these fields, in any order:

```text
size = width, height
space = grid
environment = Land
```

`size` values must evaluate to positive whole Numbers. `space` must be
`grid` or `continuous`. `environment` must name an environment that was already
declared.

A world name is metadata only. It does not create an ordinary variable:

```text
print(Meadow)
```

is still an undefined-variable error unless a normal variable named `Meadow`
was assigned separately.

## World Placement Metadata

Place an agent type in a world with coordinates:

```text
agent Blob uses:
    position.continuous
    movement.ground

environment Land:
    type = ground

world Meadow:
    size = 100, 80
    space = continuous
    environment = Land

place Blob in Meadow at 20, 35
```

This stores world-placement metadata only. To create a live instance, use
`spawn`.

Coordinate rules:

- Coordinates must be Numbers.
- In `grid` worlds, coordinates must be whole Numbers.
- In `continuous` worlds, decimal Numbers are allowed.
- `x` must be at least 0 and less than world width.
- `y` must be at least 0 and less than world height.

Position compatibility:

```text
position.cell        # grid worlds only
position.basic       # grid or continuous worlds
position.continuous  # continuous worlds only
position.none        # grid or continuous metadata placement
```

An agent with no position preset behaves like `position.none` for world
placement. Sprout does not infer or convert coordinates automatically.

World placement also validates the agent movement preset against the world's
default environment type, using the same compatibility rules as
`place Agent in Environment`.

## Live Instances, Movement, And Removal

Spawn creates a live agent instance in a world:

```text
spawn Banana as bob in Kitchen at 0, 4:
    energy = 3
```

`as name` is optional. A named instance can be read later with dotted field
access:

```text
print(bob.energy)
print(bob exists)
```

Spawn override blocks may only set fields that already exist on the agent
type. Position fields such as `x`, `y`, `row`, and `column` come from
`at x, y`, not from overrides.

Agents can define tick behavior:

```text
agent Banana uses:
    position.cell
    movement.ground
    biology.energy

    every tick:
        energy = energy - 1
        move self by 1, 0

        if energy <= 0:
            remove self
```

Inside `every tick:`, bare field names read and write the current instance.
`self` is the current instance, and `world.width` / `world.height` read the
current world dimensions.

Movement validates the whole action before applying it:

- The target instance must exist and be active.
- The movement preset must allow active movement.
- Grid movement uses whole-number coordinates.
- The target must be inside the world bounds.
- The movement preset must be compatible with the world's environment.
- Grid worlds allow only one active agent per cell. Continuous worlds allow
  overlap for now.

`move name by dx, dy` moves relative to the current position.
`move name to x, y` moves to an absolute position.

`remove name` or `remove self` marks an instance inactive immediately and frees
its grid cell. A removed instance does not update again. `name exists` returns
`false` for a removed instance, while reading a removed instance's fields is a
runtime error.

Tick updates are sequential and deterministic. Each tick snapshots the active
agents that exist at tick start, then visits each once in spawn order. Each
agent sees the current live world state, including changes made by earlier
agents in the same tick. Agents spawned during a tick begin updating on the
next tick.

## Operators

From highest to lowest precedence:

```text
() calls and grouping, [] indexing
not, unary -
* /
+ -
== != < > <= >= exists
and
or
```

`and` and `or` short-circuit, but they still require Boolean values when an
operand is evaluated.

Chained comparisons are not supported:

```text
1 < x < 10
```

Write:

```text
1 < x and x < 10
```

Ordering comparisons work with Numbers only.

## Still Out Of Scope

Sprout v0.4 does not include rendering, tiles, terrain generation, multiple
regions, overlapping environments, world transitions, pathfinding, steering
behaviors such as seek/flee/wander, collision physics beyond one grid agent per
cell, animation, GUI rendering, gravity, mutation, reproduction, food systems,
combat, perception queries, or edge wrapping/bouncing.
